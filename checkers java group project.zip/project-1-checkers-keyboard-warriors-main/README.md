# CPSC2150 - Checkers - Fall 2024

Developers:

Keyboard Warriors

Johan Zapata - psychedelic-theory

Pascual Sebastian - PascualSebastian

Nathan Kitchens - NathanK18

Uyen Nguyen - UNGUYEN09


This project should be runnable with JDK17 and Junit 4.

This project is extended version of Checkers that will run within the
command-line interface (terminal).


Overview:

A two-player checkers game on a 8x8, 10x10, 12x12, 14x14 or 16x16 grid.

Players have the option to select a fast game or memory conscious game.

A fast game is a checkers game implemented by a 2D array.

A memory conscious game is a checkers game implemented by Hashmaps.

Players are represented by a single lowercase character of their choosing. (Kinged pieces will be capitalized)

Non-playable "black tiles" are represented by asterisks (*).

Players aim to move their pieces diagonally and jump over the opponent’s pieces to remove them from the board.

A piece that reaches the opponent’s starting side is "kinged" and can move in all diagonal directions.


Game Rules:

Players take turns moving one of their pieces.

Players can jump over an opponent’s piece if there is an empty space behind it.

Only one jump is allowed per turn, and players are not required to make a jump if available.

The game ends when one player has no remaining pieces.


Program Features:

The board state is printed at the start of each turn.

Players are prompted to select one of their own pieces and choose a direction to move.

If a player selects an opponent's piece or an invalid position, they are prompted to try again.

If a selected piece cannot move, the player is asked to choose another piece.

After a player wins, the game prompts the user(s) to play again.

--------------------------------------------------------
