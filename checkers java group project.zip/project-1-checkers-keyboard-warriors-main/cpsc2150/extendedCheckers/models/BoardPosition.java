package cpsc2150.extendedCheckers.models;

/**
 * The purpose of this class is to implement the BoardPosition class.
 * @invariant 0 <= row <= 7 AND 0 <= column <= 7
 *
 */
public class BoardPosition
{

    /**
     * Row component of the BoardPosition
     */
    private int row;

    /**
     * Column component of the BoardPosition
     */
    private int column;

    /**
     * A parameterized constructor for the BoardPosition, accepts 2 params.
     * @param aRow the value to be set for the row.
     * @param aCol the value to be set for the column.
     * @return none
     *
     * @pre 0 <= aRow <= 7 AND 0 <= aCol <= 7
     *
     * @post this.row == aRow AND this.column == aCol
     */
    public BoardPosition(int aRow, int aCol) {
        /*
        Constructor for the BoardPosition object. This should set both the row and column instance variables to their
        respective parameters.
         */
        row = aRow;
        column = aCol;
    }

    /**
     * Standard getter for row
     * @param none
     *
     * @return row, an int
     *
     * @pre none
     *
     * @post getRow = row AND row = #row AND column = #column
     */
    public int getRow() {
        /*
        Typical accessor for the row instance variable.
         */
        return row;
    }

    /**
     * Standard getter for column
     * @param none
     *
     * @return column, an int
     *
     * @pre none
     *
     * @post getColumn = column AND row = #row AND column = #column
     */
    public int getColumn() {
        /*
        Typical accessor for the column instance variable.
         */
        return column;
    }

    /**
     * Compares the BoardPosition to another object for equality
     * @param obj the object to compare with the BoardPosition
     *
     * @return [true if the obj is equal to the BoardPosition and they have the same row and column
     * values, false otherwise]
     *
     * @pre obj != null
     *
     * @post equals = true if this.row == (obj.row) AND this.column == (obj.column)
     * AND equals = true if obj instanceof BoardPosition, false otherwise AND row = #row AND column = #column
     */
    public boolean equals(Object obj) {
        /*
        returns true if this BoardPosition is equal to the parameter object. Two BoardPositions are equal if their row
        and column values are the same.

        hint: it is intentional that this accepts a parameter of type Object. There is a way to check if that parameter
        Object just happens to be an instance of a BoardPosition.
         */

        if (obj instanceof BoardPosition pos) {
            return this.row == pos.row && this.column == pos.column;
        }
        return false;
    }

    /**
     * Returns the string representation of the BoardPosition
     * @param none
     *
     * @return [A string in the format of "row,column"]
     *
     * @pre none
     *
     * @post toString = row + "," column AND row = #row AND column = #column
     */
    public String toString() {
        /*
        returns a String representation of the BoardPosition in the format of "row,column"
         */
        return getRow() + "," + getColumn();
    }

}
