package cpsc2150.extendedCheckers.models;

import cpsc2150.extendedCheckers.util.DirectionEnum;
import cpsc2150.extendedCheckers.views.CheckersFE;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * The purpose of this class is to implement primary methods which will be
 * used throughout the project.
 * 
 * @invariant [board is an 2D array of characters] AND [pieceCount is a HashMap] AND [viableDirections is a HashMap]
*/
public class CheckerBoard extends AbsCheckerBoard {
    /**
     * A 2D array of characters used to represent our checkerboard.
     */
    private final char[][] board;

    /**
     * A HashMap, with a Character key and an Integer value, that is used to map a player's char to the number of
     * tokens that player still has left on the board.
     */
    private final HashMap<Character, Integer> pieceCount;

    /**
     * A HashMap, with a Character key and an ArrayList of DirectionEnums value, used to map a player (and its king
     * representation) to the directions that player can viably move in. A non-kinged (standard) piece can only move
     * in the diagonal directions away from its starting position. A kinged piece can move in the same directions the
     * standard piece can move in plus the opposite directions the standard piece can move in.
     */
    private final HashMap<Character, ArrayList<DirectionEnum>> viableDirections;
    public static final char PLAYER_ONE = 'x';
    public static final char PLAYER_TWO = 'o';
    public static final char EMPTY_POS = ' ';
    public static final char BLACK_TILE = '*';

    /*
    Standard Checkers starts with equal number of rows and columns.
     */
    private final int ROW_NUM;
    private final int COL_NUM;

    /**
     * Constructor for the CheckerBoard object.
     * 
     * @param aDimensions The dimensions of the board.
     * @return None, creates the checkerboard
     * 
     * @pre aDimensions > 0 AND [aDimensions is even] AND [the board is empty]
     *
     * @post [board is initialized to even sized grid with starting pieces in correct positions.] AND
     * [pieceCount aligns playerOne and playerTwo with startingCount] AND
     * [getViableDirections holds the correct movement directions for playerOne and playerTwo.]
     */
    public CheckerBoard(int aDimensions) {
        ROW_NUM = aDimensions;
        COL_NUM = aDimensions;

        char playerOne = CheckersFE.getPlayerOne();
        char playerTwo = CheckersFE.getPlayerTwo();
        int amountOfSpace = 2;
        int startingCount = (ROW_NUM - amountOfSpace) * (ROW_NUM / amountOfSpace) / amountOfSpace;
        pieceCount = new HashMap<>();
        pieceCount.put(playerOne, startingCount);
        pieceCount.put(playerTwo, startingCount);

        viableDirections = new HashMap<>();

        ArrayList<DirectionEnum> playerOneDir = new ArrayList<>();
        playerOneDir.add(DirectionEnum.SE);
        playerOneDir.add(DirectionEnum.SW);

        ArrayList<DirectionEnum> playerTwoDir = new ArrayList<>();
        playerTwoDir.add(DirectionEnum.NE);
        playerTwoDir.add(DirectionEnum.NW);

        viableDirections.put(playerOne, playerOneDir);
        viableDirections.put(playerTwo, playerTwoDir);

        board = new char[ROW_NUM][COL_NUM];
        //Allocates the correct pieces to the 2d array
        for (int row = 0; row < ROW_NUM; row++) {
            for (int col = 0; col < COL_NUM; col++) {
                if ((row + col) % 2 != 0) {
                    board[row][col] = BLACK_TILE;
                } else {
                    if (row < (ROW_NUM / 2) - 1) {
                        board[row][col] = playerOne;
                    } else if (row > ROW_NUM / 2) {
                        board[row][col] = playerTwo;
                    } else {
                        board[row][col] = EMPTY_POS;
                    }
                }
            }
        }
    }

    /**
     * Returns the 2D array representing the board.
     * 
     * @param None
     * @return the viableDirections HashMap
     * 
     * @pre none
     * 
     * @post getViableDirections = viableDirections AND viableDirections = #viableDirections
     */
    public HashMap<Character, ArrayList<DirectionEnum>> getViableDirections() {
        return viableDirections;
    }


    
    /**
     * Retrieves a map of the remaining piece counts for each player.
     * 
     * @param None
     *
     * @return [a map where each key is a player identifier and each value is the count of their remaining pieces]
     *
     * @pre none
     *
     * @post getPieceCounts = pieceCount AND pieceCount = #pieceCount
     */
    public HashMap<Character, Integer> getPieceCounts() {
        return pieceCount;
    }

    /**
     * Places a piece on the board for a specific player at a given position.
     * @param pos The position on the board where the piece should be placed.
     * @param player The character representing the player ('x', 'X', 'o', 'O').
     * 
     * @return None
     *
     * @pre [pos is within board bounds (0 <= pos.getRow() < getRowNum and 0 <= pos.getCol() < getColNum)]
     *      AND [player is a valid player identifier]
     * @post [The specified position on the board has the player's piece]
     */
    public void placePiece(BoardPosition pos, char player) {
        int row = pos.getRow(), col = pos.getColumn();

        board[row][col] = player;
    }

    /**
     * Retrieves the character at a specific position on the board.
     * 
     * @param pos The position on the board to check.
     * 
     * @return The character representing the player at the given position, 
     *         or a space if the position is empty.
     * 
     * @pre [pos is within board bounds (0 <= pos.getRow() < getRowNum and 0 <= pos.getCol() < getColNum)]
     * 
     * @post [The character at the specified position is returned]
     */
    public char whatsAtPos(BoardPosition pos) {
        char charAtPos;
        int row = pos.getRow(), col = pos.getColumn();

        charAtPos = board[row][col];

        return charAtPos;
    }

    
    /**
     * Retrieves the number of rows on the board.
     * 
     * @param None
     * 
     * @return The number of rows on the board.
     * 
     * @pre none
     * @post getRowNum = [number of rows]
     */
    public int getRowNum() {
        return ROW_NUM;
    }

    /**
     * Retrieves the number of columns on the board.
     * 
     * @param None
     *
     * @return The number of columns on the board.
     *
     * @pre none
     * @post getColNum = [number of columns]
     */
    public int getColNum() {
        return COL_NUM;
    }
}
