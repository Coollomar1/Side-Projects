package cpsc2150.extendedCheckers.models;


import static cpsc2150.extendedCheckers.models.CheckerBoard.BLACK_TILE;
import static cpsc2150.extendedCheckers.models.CheckerBoard.EMPTY_POS;
import cpsc2150.extendedCheckers.util.DirectionEnum;
import cpsc2150.extendedCheckers.views.CheckersFE;
import java.util.*;

/**
 * The purpose of this class is to implement primary methods using a Map implementation which will be
 * used throughout the project.
 * @invariant [board is an 2D array of characters] AND [pieceCount is a HashMap] AND [viableDirections is a HashMap]
*/
public class CheckerBoardMem extends AbsCheckerBoard {
    private final HashMap<Character, List<BoardPosition>> board;
    private final int ROW_NUM;
    private final int COL_NUM;
    private final HashMap<Character, Integer> pieceCounts;
    private final HashMap<Character, ArrayList<DirectionEnum>> viableDirections;

    /**
     * Constructor for the CheckerBoardMem object.
     * @param aDimensions
     * @return None, creates the checkerboard
     * 
     * @pre aDimensions > 0 AND [aDimensions is even] AND [the board is empty]
     *
     * @post [board is initialized to even sized grid with starting pieces in correct positions.] AND
     * [pieceCount aligns playerOne and playerTwo with startingCount] AND
     * [getViableDirections holds the correct movement directions for playerOne and playerTwo.]
     */
    public CheckerBoardMem(int aDimensions) {
        ROW_NUM = aDimensions;
        COL_NUM = aDimensions;
        board = new HashMap<>();
        pieceCounts = new HashMap<>();
        viableDirections = new HashMap<>();

        initializeBoard();
    }
    /**
     * Initializes the checkerboard by setting up the starting positions for the players and their pieces.
     * It configures the board for both regular and crowned pieces, assigns initial piece counts to each player,
     * and establishes viable movement directions. The method ensures that each player's pieces are placed in
     * the correct starting positions on the board.
     * 
     * @param None
     * @return None
     *
     * @pre [ROW_NUM and COL_NUM are set and represent the dimensions of the board]
     * @post [board is populated with initial piece positions for both players, and pieceCounts and 
     *        viableDirections are properly initialized for each player]
     */
    private void initializeBoard() {
        char playerOne = CheckersFE.getPlayerOne();
        char playerTwo = CheckersFE.getPlayerTwo();

        // Ensure both regular and crowned pieces lists are initialized for both players
        board.put(playerOne, new ArrayList<>());
        board.put(playerTwo, new ArrayList<>());
        board.put(Character.toUpperCase(playerOne), new ArrayList<>());
        board.put(Character.toUpperCase(playerTwo), new ArrayList<>());

        int amountOfSpace = 2;
        int startCount = (ROW_NUM - amountOfSpace) * (ROW_NUM / amountOfSpace) / amountOfSpace;

        pieceCounts.put(playerOne, startCount);
        pieceCounts.put(playerTwo, startCount);

        ArrayList<DirectionEnum> playerOneDirections = new ArrayList<>(Arrays.asList(DirectionEnum.SE, DirectionEnum.SW));
        ArrayList<DirectionEnum> playerTwoDirections = new ArrayList<>(Arrays.asList(DirectionEnum.NE, DirectionEnum.NW));

        viableDirections.put(playerOne, playerOneDirections);
        viableDirections.put(playerTwo, playerTwoDirections);

        for (int row = 0; row < ROW_NUM; row++) {
            for (int col = 0; col < COL_NUM; col++) {
                //Checks if tiles are black
                if ((col % 2 == 0 && row % 2 == 1) || (col % 2 == 1 && row % 2 == 0)) {
                    continue;
                }

                BoardPosition pos = new BoardPosition(row, col);

                if (row < (ROW_NUM / 2) - 1) {
                    board.get(playerOne).add(pos);
                } else if (row > (ROW_NUM / 2)) {
                    board.get(playerTwo).add(pos);
                }
            }
        }
    }

    
    
    /**
     * Returns the 2D array representing the board.
     * 
     * @param None
     * @return the viableDirections HashMap
     * 
     * @pre none
     * 
     * @post getViableDirections = viableDirections AND viableDirections = #viableDirections
     */
    @Override
    public HashMap<Character, ArrayList<DirectionEnum>> getViableDirections() {
        return viableDirections;
    }

    /**
     * Retrieves a map of the remaining piece counts for each player.
     * 
     * @param None
     *
     * @return [a map where each key is a player identifier and each value is the count of their remaining pieces]
     *
     * @pre none
     *
     * @post getPieceCounts = pieceCount AND pieceCount = #pieceCount
     */
    @Override
    public HashMap<Character, Integer> getPieceCounts() {
        return pieceCounts;
    }

    /**
     * Places a piece on the board for a specific player at a given position.
     * @param pos The position on the board where the piece should be placed.
     * @param player The character representing the player ('x', 'X', 'o', 'O').
     * 
     * @return None
     *
     * @pre [pos is within board bounds (0 <= pos.getRow() < getRowNum and 0 <= pos.getCol() < getColNum)]
     *      AND [player is a valid player identifier]
     * @post [The specified position on the board has the player's piece]
     */
    public void placePiece(BoardPosition pos, char player) {
        // Ensuresthat the player's list exists in the board map before modifying it
        List<BoardPosition> playerPositions = board.get(player);

        if (playerPositions == null) {
            playerPositions = new ArrayList<>();
            board.put(player, playerPositions);
        }

        // Removes the piece from any existing position
        for (List<BoardPosition> positions : board.values()) {
            positions.remove(pos);
        }

        playerPositions.add(pos);
    }

    /**
     * Retrieves the character at a specific position on the board.
     * 
     * @param pos The position on the board to check.
     * 
     * @return The character representing the player at the given position, 
     *         or a space if the position is empty.
     * 
     * @pre [pos is within board bounds (0 <= pos.getRow() < getRowNum and 0 <= pos.getCol() < getColNum)]
     * 
     * @post [The character at the specified position is returned]
     */
    @Override
    public char whatsAtPos(BoardPosition pos) {
        for (Map.Entry<Character, List<BoardPosition>> entry : board.entrySet()) {
            if (entry.getValue().contains(pos)) {
                return entry.getKey();
            }
        }
        //Checks if the tiles are black
        if ((pos.getColumn() % 2 == 0 && pos.getRow() % 2 == 1) || (pos.getColumn() % 2 == 1 && pos.getRow() % 2 == 0)) {
            return BLACK_TILE;
        }
        return EMPTY_POS;
    }


    /**
     * Retrieves the number of rows on the board.
     * 
     * @param None
     * 
     * @return The number of rows on the board.
     * 
     * @pre none
     * @post getRowNum = [number of rows]
     */
    @Override
    public int getRowNum() {
        return ROW_NUM;
    }

    /**
     * Retrieves the number of columns on the board.
     * 
     * @param None
     *
     * @return The number of columns on the board.
     *
     * @pre none
     * @post getColNum = [number of columns]
     */
    @Override
    public int getColNum() {
        return COL_NUM;
    }
}