package cpsc2150.extendedCheckers.models;

import static cpsc2150.extendedCheckers.models.CheckerBoard.*;
import cpsc2150.extendedCheckers.util.DirectionEnum;
import cpsc2150.extendedCheckers.views.CheckersFE;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * ICheckerBoard is an interface for representing a square checkerboard with
 * a fixed number of rows and columns.
 *
 * @Initialization_ensures:
 *          The board will be initialized with BOARD_DIMENSIONS * BOARD_DIMENSIONS cells.
 * @defines:
 *          BOARD_DIMENSIONS: an int, the number of rows and columns for the board.
 *          playerPieces: a map between each player and their remaining piece counts on the board.
 *          movementDirections: a map between each player and their viable movement directions.
 *          boardPositions: a 2D grid representing the checkerboard.
 * @constraints:
 *          BOARD_DIMENSIONS >= 1 AND BOARD_DIMENSIONS <= 8
 */

public interface ICheckerBoard {
    public static final int BOARD_DIMENSIONS = 8;

    /**
     * Retrieves a map of viable movement directions for each player.
     * 
     * @param none
     *
     * @return [a map where each key is a player identifier and each value is an ArrayList of viable movement directions.]
     * 
     * @pre none
     *
     * @post getViableDirections = movementDirections
     */
    public HashMap<Character, ArrayList<DirectionEnum>> getViableDirections();
    
    /**
     * Retrieves a map of the remaining piece counts for each player.
     * @param none
     *
     * @return [a map where each key is a player identifier and each value is the count of their remaining pieces]
     *
     * @pre none
     *
     * @post getPieceCounts = playerPieces
     */
    public HashMap<Character, Integer> getPieceCounts();

    /**
     * Places a piece on the board for a specific player at a given position.
     * @param pos The position on the board where the piece should be placed.
     * @param player The character representing the player .
     *
     * @pre [pos is within board bounds (0 <= pos.getRow() < getRowNum && 0 <= pos.getCol() < getColNum)]
     *      AND [player is a valid player identifier]
     * @post [The specified position on the board has the player's piece]
     */
    public void placePiece(BoardPosition pos, char player);

    /**
     * Retrieves the character at a specific position on the board.
     * @param pos The position on the board to check.
     *
     * @return [the character at the specified position, which may a single lower case character, EMPTY_POS, or BLACK_TILE]
     *
     * @pre [pos is within board bounds (0 <= pos.getRow() < BOARD_DIMENSIONS && 0 <= pos.getCol() < BOARD_DIMENSIONS)]
     *
     * @post whatsAtPos = boardPositions[pos.getRow()][pos.getCol()]
     */
    public char whatsAtPos(BoardPosition pos);

    /**
     * Checks if a player has won the game by verifying if all remaining pieces on the board belong to that player.
     * @param player the character representing the player.
     *
     * @return [true if all remaining pieces on the board belong to the player, false otherwise]
     *
     * @pre [player is a valid player identifier]
     *
     * @post checkPlayerWin = [true if all remaining pieces on the board belong to player]
     */
    default public boolean checkPlayerWin(Character player) {
        char opponent = (player == CheckersFE.getPlayerOne()) ? CheckersFE.getPlayerTwo() : CheckersFE.getPlayerOne();

        Map<Character, Integer> pieceCounts = getPieceCounts(); //gets pieces counts

        return pieceCounts.get(opponent) == 0;
    }

    /**
     * Crowns a piece at a given position, changing it to its uppercase equivalent.
     * @param posOfPlayer The position of the piece to be crowned.
     * 
     * @return None
     *
     * @pre [posOfPlayer is within board bounds and contains a player's piece]
     *
     * @post crownPiece = [the piece at posOfPlayer is converted to its uppercase representation]
     */
    default public void crownPiece(BoardPosition posOfPlayer) {
        char piece = whatsAtPos(posOfPlayer);

        if (Character.isUpperCase(piece)) {
            return;
        }

        if ((piece == CheckersFE.getPlayerOne() && posOfPlayer.getRow() == getColNum() - 1) ||
                (piece == CheckersFE.getPlayerTwo() && posOfPlayer.getRow() == 0)) {
            placePiece(posOfPlayer, Character.toUpperCase(piece));
        }
    }


    /**
     * Moves a piece from a starting position in a specified direction.
     * @param startingPos The starting position of the player's piece.
     * @param dir The direction of movement.
     *
     * @return [a new BoardPosition representing the piece's new location following the move]
     *
     * @pre [startingPos is within board bounds and dir is a valid direction]
     *
     * @post movePiece = [the piece moves according to dir, the original position is set to EMPTY_POS]
     */
    default public BoardPosition movePiece(BoardPosition startingPos, DirectionEnum dir) {
        // Get the piece at the starting position
        char piece = whatsAtPos(startingPos);

        // Get the direction offset and target position
        BoardPosition offset = getDirection(dir);
        BoardPosition targetPos = new BoardPosition(
                startingPos.getRow() + offset.getRow(),
                startingPos.getColumn() + offset.getColumn()
        );

        // Ensure the target position is within bounds
        if (targetPos.getRow() < 0 || targetPos.getRow() >= getRowNum()
                || targetPos.getColumn() < 0 || targetPos.getColumn() >= getColNum()) {
            return null; // Out of bounds, invalid move
        }

        // Move the piece to the target position, even if it is occupied
        placePiece(startingPos, EMPTY_POS);  // Remove the piece from the starting position
        placePiece(targetPos, piece);        // Place the piece at the target position

        // Return the new position
        return targetPos;
    }
    /**
     * Moves a piece by jumping an opponent's piece in the specified direction.
     *
     * @param startingPos The initial position of the piece.
     * @param dir         The direction in which the piece will jump.
     * @return [a new BoardPosition representing the piece's new location following the jump.]
     * @pre [startingPos is within board bounds, dir is a valid direction, and an opponent's piece can be jumped.]
     * @post jumpPiece = [the jumped position is now EMPTY_POS and the opponent's piece count is decremented]
     */
    default public BoardPosition jumpPiece(BoardPosition startingPos, DirectionEnum dir) {
        // Get the offset for the direction
        BoardPosition offset = getDirection(dir);

        // Calculate the position of the piece to jump over
        BoardPosition jumpOverPos = new BoardPosition(
                startingPos.getRow() + offset.getRow(),
                startingPos.getColumn() + offset.getColumn()
        );

        // Calculate the landing position after the jump
        BoardPosition landingPos = new BoardPosition(
                startingPos.getRow() + 2 * offset.getRow(),
                startingPos.getColumn() + 2 * offset.getColumn()
        );

        //Validates that jumpOverPos and landingPos are within bounds
        if (jumpOverPos.getRow() < 0 || jumpOverPos.getRow() >= getRowNum()
                || jumpOverPos.getColumn() < 0 || jumpOverPos.getColumn() >= getColNum()
                || landingPos.getRow() < 0 || landingPos.getRow() >= getRowNum()
                || landingPos.getColumn() < 0 || landingPos.getColumn() >= getColNum()) {
            return null;
        }

        // Retrieve the characters at each position
        char opponent = whatsAtPos(jumpOverPos);
        char player = whatsAtPos(startingPos);

        // Ensure we're jumping over an opponent's piece
        if (opponent != EMPTY_POS && opponent != BLACK_TILE && opponent != player) {
            // Capture the opponent's piece
            placePiece(jumpOverPos, EMPTY_POS);

            // Update the piece count if the opponent piece is found in the map
            Integer count = getPieceCounts().get(opponent);
            if (count != null) {
                getPieceCounts().put(opponent, count - 1);
            }

            // Move the player's piece to the landing position
            placePiece(startingPos, EMPTY_POS);
            placePiece(landingPos, player);

            return landingPos;
        }
        return null;
    }
    /**
     * Scans the positions surrounding a starting position and returns a map of the contents found in each direction.
     * @param startingPos The starting position to scan around.
     *
     * @return [a map of directions to characters found at the surrounding positions]
     *
     * @pre [startingPos is within board bounds]
     *
     * @post scanSurroundingPositions = [a map of DirectionEnum to characters at positions surrounding startingPos]
     */
    default public HashMap<DirectionEnum, Character> scanSurroundingPositions(BoardPosition startingPos) {
        HashMap<DirectionEnum, Character> surroundingPositions = new HashMap<>();

        Map<DirectionEnum, BoardPosition> directionPositions = Map.of(
                DirectionEnum.NE, new BoardPosition(startingPos.getRow() - 1, startingPos.getColumn() + 1),
                DirectionEnum.NW, new BoardPosition(startingPos.getRow() - 1, startingPos.getColumn() - 1),
                DirectionEnum.SE, new BoardPosition(startingPos.getRow() + 1, startingPos.getColumn() + 1),
                DirectionEnum.SW, new BoardPosition(startingPos.getRow() + 1, startingPos.getColumn() - 1)
        );

        for (Map.Entry<DirectionEnum, BoardPosition> entry : directionPositions.entrySet()) {
            DirectionEnum dir = entry.getKey();
            BoardPosition pos = entry.getValue();

            if (pos.getRow() >= 0 && pos.getRow() < getRowNum() && pos.getColumn() >= 0 && pos.getColumn() < getColNum()) {
                surroundingPositions.put(dir, whatsAtPos(pos));
            } else {
                surroundingPositions.put(dir, EMPTY_POS);
            }
        }
        return surroundingPositions;
    }

    /**
     * Generates a new BoardPosition representing movement in a specific direction.
     * @param dir         The direction of movement.
     * @return [a new BoardPosition reflecting movement in the specified direction.]
     * @pre [dir is not null]
     * @post getDirection = [a new BoardPosition reflecting the direction of movement]
     */
    public static BoardPosition getDirection(DirectionEnum dir) {
        switch (dir) {
            case NE:
                return new BoardPosition(- 1, + 1);
            case NW:
                return new BoardPosition(- 1, - 1);
            case SE:
                return new BoardPosition(+ 1, + 1);
            case SW:
                return new BoardPosition(+ 1, - 1);
            default:
                return null;
        }
    }

    /**
     * Retrieves the number of rows on the board.
     * 
     * @param None
     *
     * @return [the number of rows on the board]
     *
     * @pre none
     *
     * @post getRowNum = [number of rows]
     */
    public int getRowNum();

    /**
     * Retrieves the number of columns on the board.
     * 
     * @param None
     *
     * @return [the number of columns on the board]
     *
     * @pre none
     *
     * @post getColNum = [number of columns]
     */
    public int getColNum();

}
