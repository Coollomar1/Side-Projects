package cpsc2150.extendedCheckers.models;

/**
 * 
 * This class is an abstract class that provides a base implementation of the ICheckerBoard interface.
 * 
 * @invariant dimensionCheck >= 0
 * 
 */
public abstract class AbsCheckerBoard implements ICheckerBoard {
    private int dimensionCheck;
    /**
     * Provides a formatted string representation of the checkerboard, displaying each piece on the board and their
     * current positions.
     * 
     * @param None
     *
     * @return [a formatted string representation of the checkerboard with headers for rows and columns.]
     *
     * @pre None
     * @post toString = [a string representing the checkerboard with row and column headers and pieces in their
     *       respective positions.]
     */
    public String toString() {
       StringBuilder sb = new StringBuilder();
       int doubleDigit = 10;

       sb.append("|  |");
       for (int col = 0; col < getColNum(); col++) {

           if (col >= doubleDigit) {
               sb.append(col).append("|");
           }
           else {
               sb.append(" ").append(col).append("|");
           }
        }
       sb.append("\n");

       for (int row = 0; row < getRowNum(); row++) {
           sb.append("|");
           if (row >= doubleDigit) {
               sb.append(row).append("|");
           }
           else {
               sb.append(row).append(" |");
           }
           for (int col = 0; col < getColNum(); col++) {
               BoardPosition pos = new BoardPosition(row, col);
               sb.append(whatsAtPos(pos)).append(" |");
           }
           sb.append("\n");
       }
       return sb.toString();
    }
}
