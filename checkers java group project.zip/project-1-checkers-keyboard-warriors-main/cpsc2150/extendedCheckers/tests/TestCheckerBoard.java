package cpsc2150.extendedCheckers.tests;
import static cpsc2150.extendedCheckers.models.CheckerBoard.EMPTY_POS;
import static org.junit.Assert.*;

import cpsc2150.extendedCheckers.util.DirectionEnum;
import org.junit.Test;
import cpsc2150.extendedCheckers.models.*;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class TestCheckerBoard
{
    private String arrToString(char[][] board)
    {
        StringBuilder s = new StringBuilder("|  |");
        int numRows = board.length;
        int numCols = board[0].length;

        // Create column headers
        for (int i = 0; i < numCols; i++) {
            if (i < 10) {
                s.append(" ").append(i).append("|");
            } else {
                s.append(i).append("|");
            }
        }
        s.append("\n");

        for (int i = 0; i < numRows; i++) {
            if (i < 10) {
                s.append("|").append(i).append(" ");
            } else {
                s.append("|").append(i);
            }

            for (int j = 0; j < numCols; j++) {
                s.append("|");
                char pos = board[i][j];
                if (pos != '*') {
                    s.append(pos).append(" ");
                } else {
                    s.append("* ");
                }
            }
            s.append("|\n");
        }
        return s.toString();
    }

    private ICheckerBoard makeBoard() {
        return new CheckerBoard(8);
    }

    @Test
    public void Test_CheckerBoard_Constructor()
    {
        ICheckerBoard cb = makeBoard();
        String observed = cb.toString();

        char[][] expectedBoard = {
                {'x', '*','x', '*', 'x', '*', 'x', '*'},
                {'*', 'x','*', 'x', '*', 'x', '*', 'x'},
                {'x', '*','x', '*', 'x', '*', 'x', '*'},
                {'*', ' ','*', ' ', '*', ' ', '*', ' '},
                {' ', '*',' ', '*', ' ', '*', ' ', '*'},
                {'*', 'o','*', 'o', '*', 'o', '*', 'o'},
                {'o', '*','o', '*', 'o', '*', 'o', '*'},
                {'*', 'o','*', 'o', '*', 'o', '*', 'o'},
        };

        String expected = arrToString(expectedBoard);
        assertEquals(expected, observed);
    }

    @Test
    public void Test_whatsAtPos_MaxRow_MinCol_Black_Tile ()
    {
        ICheckerBoard cb = makeBoard();
        BoardPosition inputPos = new BoardPosition(7,0);

        char observed = cb.whatsAtPos(inputPos);
        char expected = '*';

        assertEquals(expected, observed);
    }

    @Test
    public void Test_whatsAtPos_MinRow_MaxCol_Black_Tile()
    {
        ICheckerBoard cb = makeBoard();
        BoardPosition inputPos = new BoardPosition(0,7);

        char observed = cb.whatsAtPos(inputPos);
        char expected = '*';

        assertEquals(expected, observed);
    }

    @Test
    public void Test_whatsAtPos_MaxRow_MaxCol_Player_Two()
    {
        ICheckerBoard cb = makeBoard();
        BoardPosition inputPos = new BoardPosition(7,7);

        char observed = cb.whatsAtPos(inputPos);
        char expected = 'o';

        assertEquals(expected, observed);
    }

    @Test
    public void Test_whatsAtPos_MinRow_MinCol_Player_One()
    {
        ICheckerBoard cb = makeBoard();
        BoardPosition inputPos = new BoardPosition(0,0);

        char observed = cb.whatsAtPos(inputPos);
        char expected = 'x';

        assertEquals(expected, observed);
    }

    @Test
    public void Test_whatsAtPos_Row3_Col3_Empty_Pos()
    {
        ICheckerBoard cb = makeBoard();
        BoardPosition inputPos = new BoardPosition(3,3);

        char observed = cb.whatsAtPos(inputPos);
        char expected = ' ';

        assertEquals(expected, observed);
    }

    @Test
    public void Test_placePiece_MinRow_MinCol_Player_Two()
    {
        ICheckerBoard cb = makeBoard();
        BoardPosition inputPos = new BoardPosition(0,0);
        char inputPlayer = 'o';

        cb.placePiece(inputPos, inputPlayer);

        String observed = cb.toString();

        char[][] expectedBoard = {
                {'o', '*','x', '*', 'x', '*', 'x', '*'},
                {'*', 'x','*', 'x', '*', 'x', '*', 'x'},
                {'x', '*','x', '*', 'x', '*', 'x', '*'},
                {'*', ' ','*', ' ', '*', ' ', '*', ' '},
                {' ', '*',' ', '*', ' ', '*', ' ', '*'},
                {'*', 'o','*', 'o', '*', 'o', '*', 'o'},
                {'o', '*','o', '*', 'o', '*', 'o', '*'},
                {'*', 'o','*', 'o', '*', 'o', '*', 'o'},
        };

        String expected = arrToString(expectedBoard);
        assertEquals(expected, observed);
    }

    @Test
    public void Test_placePiece_MaxRow_MinCol_Player_One()
    {
        ICheckerBoard cb = makeBoard();
        BoardPosition inputPos = new BoardPosition(7,0);
        char inputPlayer = 'x';

        cb.placePiece(inputPos, inputPlayer);

        String observed = cb.toString();
        char[][] expectedBoard = {
                {'x', '*','x', '*', 'x', '*', 'x', '*'},
                {'*', 'x','*', 'x', '*', 'x', '*', 'x'},
                {'x', '*','x', '*', 'x', '*', 'x', '*'},
                {'*', ' ','*', ' ', '*', ' ', '*', ' '},
                {' ', '*',' ', '*', ' ', '*', ' ', '*'},
                {'*', 'o','*', 'o', '*', 'o', '*', 'o'},
                {'o', '*','o', '*', 'o', '*', 'o', '*'},
                {'x', 'o','*', 'o', '*', 'o', '*', 'o'},
        };

        String expected = arrToString(expectedBoard);
        assertEquals(expected, observed);
    }

    @Test
    public void Test_placePiece_MaxRow_MaxCol_Player_One()
    {
        ICheckerBoard cb = makeBoard();
        BoardPosition inputPos = new BoardPosition(7,7);

        char inputPlayer = 'x';

        cb.placePiece(inputPos, inputPlayer);

        String observed = cb.toString();
        char[][] expectedBoard = {
                {'x', '*','x', '*', 'x', '*', 'x', '*'},
                {'*', 'x','*', 'x', '*', 'x', '*', 'x'},
                {'x', '*','x', '*', 'x', '*', 'x', '*'},
                {'*', ' ','*', ' ', '*', ' ', '*', ' '},
                {' ', '*',' ', '*', ' ', '*', ' ', '*'},
                {'*', 'o','*', 'o', '*', 'o', '*', 'o'},
                {'o', '*','o', '*', 'o', '*', 'o', '*'},
                {'*', 'o','*', 'o', '*', 'o', '*', 'x'},
        };

        String expected = arrToString(expectedBoard);
        assertEquals(expected, observed);
    }

    @Test
    public void Test_MinRow_MaxCol_Player_Two()
    {
        ICheckerBoard cb = makeBoard();
        BoardPosition inputPos = new BoardPosition(0, 7);
        char inputPlayer = 'o';

        cb.placePiece(inputPos, inputPlayer);
        String observed = cb.toString();
        char[][] expectedBoard = {
                {'x', '*', 'x', '*', 'x', '*', 'x', 'o'},
                {'*', 'x', '*', 'x', '*', 'x', '*', 'x'},
                {'x', '*', 'x', '*', 'x', '*', 'x', '*'},
                {'*', ' ', '*', ' ', '*', ' ', '*', ' '},
                {' ', '*', ' ', '*', ' ', '*', ' ', '*'},
                {'*', 'o', '*', 'o', '*', 'o', '*', 'o'},
                {'o', '*', 'o', '*', 'o', '*', 'o', '*'},
                {'*', 'o', '*', 'o', '*', 'o', '*', 'o'},
        };

        String expected = arrToString(expectedBoard);
        assertEquals(expected, observed);
    }

    @Test
    public void Test_RandRow_RanCol_Player_Two()
    {
        ICheckerBoard cb = makeBoard();
        BoardPosition inputPos = new BoardPosition(3, 2);
        char inputPlayer = 'o';

        cb.placePiece(inputPos, inputPlayer);
        String observed = cb.toString();
        char[][] expectedBoard = {
                {'x', '*', 'x', '*', 'x', '*', 'x', '*'},
                {'*', 'x', '*', 'x', '*', 'x', '*', 'x'},
                {'x', '*', 'x', '*', 'x', '*', 'x', '*'},
                {'*', ' ', 'o', ' ', '*', ' ', '*', ' '},
                {' ', '*', ' ', '*', ' ', '*', ' ', '*'},
                {'*', 'o', '*', 'o', '*', 'o', '*', 'o'},
                {'o', '*', 'o', '*', 'o', '*', 'o', '*'},
                {'*', 'o', '*', 'o', '*', 'o', '*', 'o'},
        };

        String expected = arrToString(expectedBoard);
        assertEquals(expected, observed);
    }

    @Test
    public void Test_getPieceCounts_InitialState()
    {
        ICheckerBoard cb = makeBoard();
        int xCnt = cb.getPieceCounts().get(CheckerBoard.PLAYER_ONE);
        int oCnt = cb.getPieceCounts().get(CheckerBoard.PLAYER_TWO);

        assertEquals("Player_One should have 12 pieces", 12, xCnt);
        assertEquals("Player_Two should have 12 pieces", 12, oCnt);
    }

    @Test
    public void Test_getViableDirections_InitialState() {
        ICheckerBoard cb = makeBoard();

        // Get viable directions for both players
        Set<DirectionEnum> xViableDirections = new HashSet<>(cb.getViableDirections().get(CheckerBoard.PLAYER_ONE));
        Set<DirectionEnum> oViableDirections = new HashSet<>(cb.getViableDirections().get(CheckerBoard.PLAYER_TWO));

        // Define expected viable directions for each player
        Set<DirectionEnum> expectedPlayerOneDirections = new HashSet<>();
        expectedPlayerOneDirections.add(DirectionEnum.SE);
        expectedPlayerOneDirections.add(DirectionEnum.SW);

        Set<DirectionEnum> expectedPlayerTwoDirections = new HashSet<>();
        expectedPlayerTwoDirections.add(DirectionEnum.NE);
        expectedPlayerTwoDirections.add(DirectionEnum.NW);

        // Perform assertions
        assertEquals("The viable directions for PLAYER_ONE should be [SE, SW]", expectedPlayerOneDirections, xViableDirections);
        assertEquals("The viable directions for PLAYER_TWO should be [NE, NW]", expectedPlayerTwoDirections, oViableDirections);
    }

    @Test
    public void Test_checkPlayerWin_Player_Two_O() {
        ICheckerBoard cb = makeBoard();

        // Clear the board while keeping black tiles
        for (int row = 0; row < cb.getRowNum(); row++) {
            for (int col = 0; col < cb.getColNum(); col++) {
                BoardPosition pos = new BoardPosition(row, col);
                if (cb.whatsAtPos(pos) != CheckerBoard.BLACK_TILE) {
                    cb.placePiece(pos, CheckerBoard.EMPTY_POS);
                }
            }
        }

        // Place a single PLAYER_TWO piece
        cb.placePiece(new BoardPosition(0, 6), CheckerBoard.PLAYER_TWO);

        // Update pieceCount to reflect the current board state (one piece for PLAYER_TWO)
        cb.getPieceCounts().put(CheckerBoard.PLAYER_ONE, 0);
        cb.getPieceCounts().put(CheckerBoard.PLAYER_TWO, 1);

        // Assert that player O has pieces remaining on the board
        boolean hasOPiece = false;
        for (int row = 0; row < cb.getRowNum(); row++) {
            for (int col = 0; col < cb.getColNum(); col++) {
                if (cb.whatsAtPos(new BoardPosition(row, col)) == CheckerBoard.PLAYER_TWO) {
                    hasOPiece = true;
                    break;
                }
            }
            if (hasOPiece) {
                break;
            }
        }
        assertTrue("Player O should have pieces remaining on the board.", hasOPiece);

        // Now check if player O wins
        boolean result = cb.checkPlayerWin(CheckerBoard.PLAYER_TWO);
        assertTrue("Player 'o' should have won the game.", result);
    }

    @Test
    public void noVictory_WhenAllPiecesDoNotBelongToPlayerX()
    {
        ICheckerBoard cb = makeBoard();
        cb.placePiece(new BoardPosition(0, 4), CheckerBoard.PLAYER_ONE);

        for (int i = 0; i < CheckerBoard.BOARD_DIMENSIONS; i++)
        {
            cb.placePiece(new BoardPosition(i, 0), CheckerBoard.PLAYER_ONE);
        }


        // Check player O has at least one piece on the board
        boolean hasOPiece = false;
        for (int row = 0; row < cb.getRowNum(); row++)
        {
            for (int col = 0; col < cb.getColNum(); col++)
            {
                if (cb.whatsAtPos(new BoardPosition(row, col)) == CheckerBoard.PLAYER_TWO)
                {
                    hasOPiece = true;
                    break;
                }
            }
            if (hasOPiece)
            {
                break;
            }
        }
        // Assert that player O has pieces remaining on the board
        assertTrue("Player O should have pieces remaining on the board.", hasOPiece);

        // Now check if player X wins
        boolean result = cb.checkPlayerWin(CheckerBoard.PLAYER_ONE);
        assertFalse("Player X should not win since there are remaining O pieces on the board.", result);
    }

    @Test
    public void crownPiece_Winner_PlayerX()
    {
        ICheckerBoard cb = makeBoard();

        // Place player's X's piece at (7,2)
        BoardPosition originalPosition = new BoardPosition(7, 2);
        cb.placePiece(originalPosition, CheckerBoard.PLAYER_ONE);

        // Crown the piece
        cb.crownPiece(originalPosition);

        // Check that the piece is now crowned (should be 'X' if crowned)
        char crownedPiece = cb.whatsAtPos(new BoardPosition(7, 2));
        assertEquals("The piece at (7, 2) should be crowned X.", 'X', crownedPiece);
    }

    @Test
    public void CrownPiece_NoCrowning_WhenPieceAlreadyCrowned()
    {
        ICheckerBoard cb = makeBoard();

        // Place a crowned piece for player X at (7,0)
        BoardPosition crownedPosition = new BoardPosition(7,0);
        cb.placePiece(crownedPosition, CheckerBoard.PLAYER_ONE); // Place initial piece
        cb.crownPiece(crownedPosition); // Crown the piece

        // Save the original state of the board
        String originalBoardState = cb.toString();

        // Attempt to crown already crowned piece
        cb.crownPiece(crownedPosition);

        // Check that the board state remains unchanged
        String newBoardState = cb.toString();
        assertEquals("The state of the board should remain unchanged when attempting to crown an already crowned piece.", originalBoardState, newBoardState);
    }

    @Test
    public void crownPiece_InvalidMoveToPosition()
    {
        ICheckerBoard cb = makeBoard();

        // Place a piece for player X at (6,0)
        BoardPosition initialPosition = new BoardPosition(6, 0);
        cb.placePiece(initialPosition, CheckerBoard.PLAYER_ONE); // Place initial piece

        // Save the original state of the board
        String originalBoardState = cb.toString();

        // Attempt to crown the piece at (6,0)
        BoardPosition targetPosition = new BoardPosition(7,2);

        // Check that the board state remains unchanged
        String newBoardState = cb.toString();
        assertEquals("The state of the board should remain unchanged when attempting to crown without a valid move (out of bounds or no vacant diagonal square.", originalBoardState, newBoardState);
    }

    @Test
    public void movePiece_ValidMove_PlayerX()
    {
        ICheckerBoard cb = makeBoard();

        // Place a piece for player x at (2,0)
        BoardPosition initialPosition = new BoardPosition(2, 0);
        cb.placePiece(initialPosition, CheckerBoard.PLAYER_ONE);

        // Get the state of the board before moving
        String originalBoardState = cb.toString();

        // Move player x's piece from (2,0) to (3,1) using DirectionEnum
        DirectionEnum moveDirection = DirectionEnum.SE;
        cb.movePiece(initialPosition, moveDirection);

        // Get the state of the board after moving
        BoardPosition targetPosition = new BoardPosition(3, 1);
        String newBoardState = cb.toString();

        // Check if the piece was successfully moved to (3,1)
        assertEquals("Player x's piece should now be at position (3,1).", CheckerBoard.PLAYER_ONE, cb.whatsAtPos(targetPosition));

        assertEquals("The original position (2,0) should now be vacant.", EMPTY_POS, cb.whatsAtPos(initialPosition));
    }


    @Test
    public void testMovePiece_OverrideOccupiedPosition() {
        ICheckerBoard cb = makeBoard();

        // Place PLAYER_ONE piece at starting position (5,1)
        BoardPosition initialPosition = new BoardPosition(5, 1);
        cb.placePiece(initialPosition, CheckerBoard.PLAYER_ONE);

        // Set up an occupied destination position (6, 2) with PLAYER_TWO
        BoardPosition occupiedPosition = new BoardPosition(6, 2);
        cb.placePiece(occupiedPosition, CheckerBoard.PLAYER_TWO);

        // Move PLAYER_ONE piece to the occupied position (6, 2) in the SE direction
        DirectionEnum moveDirection = DirectionEnum.SE;
        cb.movePiece(initialPosition, moveDirection);

        // Check that the destination position now has PLAYER_ONE's piece
        assertEquals("The destination position should now be occupied by PLAYER_ONE's piece.",
                CheckerBoard.PLAYER_ONE, cb.whatsAtPos(occupiedPosition));

        // Ensure the starting position is now empty
        assertEquals("The starting position should now be empty.",
                CheckerBoard.EMPTY_POS, cb.whatsAtPos(initialPosition));
    }

    @Test
    public void movePiece_ValidMove_PlayerO()
    {
        ICheckerBoard cb = makeBoard();

        // Place a piece for player o at (4,2)
        BoardPosition initialPosition = new BoardPosition(4, 2);
        cb.placePiece(initialPosition, CheckerBoard.PLAYER_TWO);

        // Get the state of the board before moving
        String originalBoardState = cb.toString();

        // Move player o's piece from (4,2) to (3,3) using DirectionEnum
        DirectionEnum moveDirection = DirectionEnum.NE;
        cb.movePiece(initialPosition, moveDirection);

        // Get the state of the board after moving
        BoardPosition targetPosition = new BoardPosition(3, 3);
        String newBoardState = cb.toString();

        // Check if the piece was successfully moved to (3,3)
        assertEquals("Player o's piece should now be at position (3,3).", CheckerBoard.PLAYER_TWO, cb.whatsAtPos(targetPosition));

        assertEquals("The original position (4,2) should now be vacant.", EMPTY_POS, cb.whatsAtPos(initialPosition));
    }

    @Test
    public void Test_PlayerOneJumpSuccess() {
        ICheckerBoard cb = makeBoard();
        BoardPosition initialPosition = new BoardPosition(2, 2);
        DirectionEnum direction = DirectionEnum.SE;

        cb.placePiece(new BoardPosition(3, 3), 'o');
        cb.placePiece(initialPosition, 'x');

        BoardPosition result = cb.jumpPiece(initialPosition, direction);

        BoardPosition expectedNewPosition = new BoardPosition(4, 4);
        assertEquals(expectedNewPosition, result);

        assertEquals(11, (int) cb.getPieceCounts().get('o'));
        assertEquals('x', cb.whatsAtPos(new BoardPosition(4, 4)));
        assertEquals(' ', cb.whatsAtPos(initialPosition));
        assertEquals(' ', cb.whatsAtPos(new BoardPosition(3, 3)));
    }


    @Test
    public void Test_JumpBlockedByPiece() {
        ICheckerBoard cb = makeBoard();
        BoardPosition initialPosition = new BoardPosition(2, 2);
        DirectionEnum direction = DirectionEnum.NE;

        cb.placePiece(new BoardPosition(3, 3), 'o');
        cb.placePiece(new BoardPosition(4, 4), 'x');
        cb.placePiece(initialPosition, 'x');

        BoardPosition result = cb.jumpPiece(initialPosition, direction);
        assertNull(result);

        assertEquals('x', cb.whatsAtPos(new BoardPosition(2, 2)));
        assertEquals('x', cb.whatsAtPos(new BoardPosition(4, 4)));
    }


    @Test
    public void Test_PlayerTwoJumpSuccess() {
        ICheckerBoard cb = makeBoard();
        BoardPosition initialPosition = new BoardPosition(5, 1);
        DirectionEnum direction = DirectionEnum.NE;

        cb.placePiece(new BoardPosition(4, 2), 'x');
        cb.placePiece(initialPosition, 'o');

        BoardPosition result = cb.jumpPiece(initialPosition, direction);
        assertNotNull(result);

        assertEquals(11, (int) cb.getPieceCounts().get('x'));
        assertEquals('o', cb.whatsAtPos(new BoardPosition(3, 3)));
        assertEquals(' ', cb.whatsAtPos(new BoardPosition(5, 1)));
    }

    @Test
    public void Test_ScanInCenterOfBoard() {
        ICheckerBoard cb = makeBoard();
        BoardPosition initialPosition = new BoardPosition(4, 4);

        cb.placePiece(new BoardPosition(5, 5), 'o');
        cb.placePiece(new BoardPosition(5, 3), 'o');

        Map<DirectionEnum, Character> surrounding = cb.scanSurroundingPositions(initialPosition);

        assertEquals(Character.valueOf('o'), surrounding.get(DirectionEnum.SE));
        assertEquals(Character.valueOf('o'), surrounding.get(DirectionEnum.SW));
        assertEquals(Character.valueOf(' '), surrounding.get(DirectionEnum.NE));
        assertEquals(Character.valueOf(' '), surrounding.get(DirectionEnum.NW));
    }

    @Test
    public void Test_ScanEdgeOfBoard() {
        ICheckerBoard cb = makeBoard();
        BoardPosition initialPosition = new BoardPosition(0, 4);

        // Set ip the initial board state
        cb.placePiece(new BoardPosition(1,5), 'x');
        cb.placePiece(new BoardPosition(1,3), 'x');

        Map<DirectionEnum, Character> surrounding = cb.scanSurroundingPositions(initialPosition);

        assertEquals(Character.valueOf('x'), surrounding.get(DirectionEnum.SE));
        assertEquals(Character.valueOf('x'), surrounding.get(DirectionEnum.SW));
        assertEquals(Character.valueOf(' '), surrounding.get(DirectionEnum.NE));
        assertEquals(Character.valueOf(' '), surrounding.get(DirectionEnum.NW));
    }

    @Test
    public void Test_ScanCornerOfBoard() {
        ICheckerBoard cb = makeBoard();
        BoardPosition initialPosition = new BoardPosition(0,0);

        // Set up the initial board state
        cb.placePiece(new BoardPosition(1,1), 'x');

        Map<DirectionEnum, Character> surrounding = cb.scanSurroundingPositions(initialPosition);

        assertEquals(Character.valueOf('x'), surrounding.get(DirectionEnum.SE));
        assertEquals(Character.valueOf(' '), surrounding.get(DirectionEnum.SW));
        assertEquals(Character.valueOf(' '), surrounding.get(DirectionEnum.NE));
        assertEquals(Character.valueOf(' '), surrounding.get(DirectionEnum.NW));
    }

    @Test
    public void Test_SouthEastDirection() {
        ICheckerBoard cb = makeBoard();

        BoardPosition startingPos = new BoardPosition(2, 2);
        cb.placePiece(startingPos, CheckerBoard.PLAYER_ONE);

        BoardPosition expectedNewPos = new BoardPosition(3, 3);
        cb.movePiece(startingPos, DirectionEnum.SE);

        assertEquals(CheckerBoard.PLAYER_ONE, cb.whatsAtPos(expectedNewPos));
        assertEquals(EMPTY_POS, cb.whatsAtPos(startingPos));
    }
}
