package cpsc2150.extendedCheckers.views;

import cpsc2150.extendedCheckers.models.BoardPosition;
import cpsc2150.extendedCheckers.models.CheckerBoard;
import cpsc2150.extendedCheckers.models.CheckerBoardMem;
import cpsc2150.extendedCheckers.models.ICheckerBoard;
import cpsc2150.extendedCheckers.util.DirectionEnum;
import java.util.Scanner;

/**
 * The purpose of this class is to call the other classes and methods so it can
 * control the game flow of checkers.
 * This is also the only place where System.out.print/println will be called.
 */

public class CheckersFE
{
    private static char playerOne = 'x';
    private static char playerTwo = 'o';

    // define the constants for magic numbers
    public static final int BOARD_SIZE_EIGHT = 8;
    public static final int BOARD_SIZE_TEN = 10;
    public static final int BOARD_SIZE_TWELVE = 12;
    public static final int BOARD_SIZE_FOURTEEN = 14;
    public static final int BOARD_SIZE_SIXTEEN = 16;


    public static char getPlayerOne() {
        return playerOne;
    }

    public static char getPlayerTwo() {
        return playerTwo;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean playAgain = true;

        // While loop which asks if the user wants to play
        while (playAgain) {
            ICheckerBoard cb = makeBoard(scanner);
            char currPlayer = getPlayerOne();
            boolean gameWon = false;
            // While loop which keeps running until a winner is declared
            while (!gameWon) {
                System.out.println(cb);
                System.out.println("Player " + currPlayer + "'s turn.");

                BoardPosition startPos = null;

                while (startPos == null) {
                    startPos = getPosition(scanner, "Enter the position of the piece you want to move (row col)", cb); // added cb parameter to pass to getPosition function

                    if (!isValidStartPos(cb, startPos, currPlayer)) {
                        System.out.println("Invalid position or no piece at the selected position. Try again");
                        startPos = null;  // reset to prompt again for a new position
                    }
                }

                DirectionEnum direction = getMoveDirection(scanner, currPlayer, cb, startPos);

                System.out.println("Would you like to (M)ove or (J)ump?");
                char moveType = scanner.next().toUpperCase().charAt(0);

                BoardPosition newPos = null;
                boolean validMove = false;

                // Validates user moves
                while (!validMove) {
                    if (moveType == 'M') {
                        int moveStep = 1;
                        BoardPosition destinationPos = getDestinationPosition(startPos, direction, moveStep);
                        if (isWithinBounds(destinationPos, cb) && cb.whatsAtPos(destinationPos) == CheckerBoard.EMPTY_POS) {
                            newPos = cb.movePiece(startPos, direction);
                            // Crown piece if it reaches the last row
                            if (newPos != null) {
                                cb.crownPiece(newPos);
                            }
                            validMove = true;  // Move was successful
                        } else {
                            System.out.println("Move out of bounds. Try again.");
                            break;  // exit the move loop to allow piece re-selection
                        }
                    } else if (moveType == 'J') {
                        int moveJump = 2;
                        BoardPosition intermediatePos = getIntermediatePosition(startPos, direction);
                        BoardPosition destinationPos = getDestinationPosition(startPos, direction, moveJump);
                        if (isWithinBounds(intermediatePos, cb) && isWithinBounds(destinationPos, cb)) {
                            if (isOpponentPiece(cb.whatsAtPos(intermediatePos), currPlayer) && cb.whatsAtPos(destinationPos) == CheckerBoard.EMPTY_POS) {
                                newPos = cb.jumpPiece(startPos, direction);
                                // Crown piece if it reaches the last row
                                if (newPos != null) {
                                    cb.crownPiece(newPos);
                                }
                                validMove = true;  // Jump was successful
                            } else {
                                System.out.println("Invalid jump. Ensure the destination is empty and you're jumping over an opponent.");
                                break;  // exit the move loop to allow piece re-selection
                            }
                        } else {
                            System.out.println("Jump out of bounds. Try again.");
                            break;  // exit the move loop to allow piece re-selection
                        }
                    } else {
                        System.out.println("Invalid input. Please enter 'M' to move or 'J' to jump.");
                        break;  // exit the move loop to allow piece re-selection
                    }
                }

                if (newPos == null) {
                    System.out.println("Invalid move. Try again.");
                    continue;  // continue the game loop to retry
                }

                if (cb.checkPlayerWin(currPlayer)) {
                    System.out.println("Player " + currPlayer + " wins the game");
                    gameWon = true;
                } else {
                    currPlayer = (currPlayer == getPlayerOne() ? getPlayerTwo() : getPlayerOne());
                }
            }
            System.out.println("\nWould you like to play again? y/n");
            while (true) {
                String userSelection = scanner.next();
                if (userSelection.equalsIgnoreCase("n")) {
                    System.out.println("\nThank you for playing!");
                    System.exit(0);
                }
                else if (userSelection.equalsIgnoreCase("y")) {
                    break;
                }
                else {
                    System.out.println("Please enter 'y' or 'n'.");
                }
            }
        }
    }

    // Helper methods to calculate positions with boundary checks
    private static BoardPosition getIntermediatePosition(BoardPosition start, DirectionEnum direction) {
        int row = start.getRow();
        int col = start.getColumn();
        switch (direction) {
            case NE: return new BoardPosition(row - 1, col + 1);
            case NW: return new BoardPosition(row - 1, col - 1);
            case SE: return new BoardPosition(row + 1, col + 1);
            case SW: return new BoardPosition(row + 1, col - 1);
            default: throw new IllegalArgumentException("Invalid direction for jump.");
        }
    }

    private static BoardPosition getDestinationPosition(BoardPosition start, DirectionEnum direction, int steps) {
        int row = start.getRow();
        int col = start.getColumn();
        switch (direction) {
            case NE: return new BoardPosition(row - steps, col + steps);
            case NW: return new BoardPosition(row - steps, col - steps);
            case SE: return new BoardPosition(row + steps, col + steps);
            case SW: return new BoardPosition(row + steps, col - steps);
            default: throw new IllegalArgumentException("Invalid direction.");
        }
    }

    // Helper to get the opponent character
    private static char getOpponent(char player) {
        return (player == getPlayerOne()) ? getPlayerTwo() : getPlayerOne();
    }

    private static boolean isOpponentPiece(char piece, char player) {
        return piece == getOpponent(player) || piece == Character.toUpperCase(getOpponent(player));
    }
    
    // this kept crashing everytime a user tried to input anything out of bounds
    private static BoardPosition getPosition(Scanner scanner, String prompt, ICheckerBoard cb) {
    
        // create local variables to be stored when returning the board position
        int row;
        int col;
        
        // for input validation
        while (true) {
            System.out.println(prompt);
            row = scanner.nextInt();
            col = scanner.nextInt();
            
            // for some reason, when I would try to input anything out of bounds, whole program would crash
            // so I just created a while loop to fix it
            if (row < 0 || row >= cb.getRowNum() || col < 0 || col >= cb.getColNum()) {
                System.out.println("Invalid position. Please enter a position within the bounds of the board.");
            } else {
                break;
            }
        }
        // return the board position
        return new BoardPosition(row, col);
    }

    private static boolean isValidStartPos(ICheckerBoard cb, BoardPosition pos, char player) {
        char pieceAtPos = cb.whatsAtPos(pos);
        // Allow crowned pieces to be valid selections as well
        return (pieceAtPos == player || pieceAtPos == Character.toUpperCase(player));
    }

    private static DirectionEnum getMoveDirection(Scanner scanner, char currPlayer, ICheckerBoard cb, BoardPosition startPos) {
        // Check if the selected piece is crowned
        boolean isCrowned = isCrownedPiece(cb, startPos, currPlayer);

        // Define allowed directions based on whether the player is crowned
        String validDirections = isCrowned ? "SW, SE, NW, NE" : (currPlayer == getPlayerOne() ? "SW, SE" : "NW, NE");

        System.out.println("Allowed directions for player " + currPlayer + " are: " + validDirections);
        System.out.println("Enter the direction to move: ");

        String directionInput = scanner.next().toUpperCase();

        // Validate the direction input
        while (!isValidDirectionForPlayer(directionInput, currPlayer, isCrowned)) {
            System.out.println("Invalid direction. Please enter one of the following: " + validDirections);
            directionInput = scanner.next().toUpperCase();
        }

        // Return the corresponding DirectionEnum value
        switch (directionInput) {
            case "NE":
                return DirectionEnum.NE;
            case "NW":
                return DirectionEnum.NW;
            case "SE":
                return DirectionEnum.SE;
            case "SW":
                return DirectionEnum.SW;
            default:
                throw new IllegalArgumentException("Unexpected direction: " + directionInput);
        }
    }

    private static boolean isCrownedPiece(ICheckerBoard cb, BoardPosition pos, char player) {
        // Check if the piece at the position is crowned (upper case version of the player)
        char pieceAtPos = cb.whatsAtPos(pos);
        return (pieceAtPos == Character.toUpperCase(player));
    }

    private static boolean isValidDirectionForPlayer(String direction, char player, boolean isCrowned) {
        // Allow crowned pieces to move in any direction
        if (isCrowned) {
            return direction.equals("NE") || direction.equals("NW") || direction.equals("SE") || direction.equals("SW");
        }

        // Otherwise, restrict directions based on regular player type
        if (player == getPlayerOne()) {
            return direction.equals("SW") || direction.equals("SE");
        } else {
            return direction.equals("NW") || direction.equals("NE");
        }
    }

    private static boolean isWithinBounds(BoardPosition pos, ICheckerBoard cb) {
        int row = pos.getRow();
        int col = pos.getColumn();
        return row >= 0 && row < cb.getRowNum() && col >= 0 && col < cb.getColNum();
    }

    private static ICheckerBoard makeBoard(Scanner scanner) {
        System.out.println("Player 1, enter your piece letter (lowercase only):");
        playerOne = (char) getLowercaseChar(scanner);
        System.out.println("Player 2, enter your piece letter (lowercase only):");
        playerTwo = (char) getLowercaseChar(scanner);

        System.out.println("Do you want a fast game (F/f) or a memory efficient game (M/m)?");
        char gameType = getGameType(scanner);

        System.out.println("How big should the board be? It can be 8x8, 10x10, 12x12, 14x14, or 16x16. Enter one number:");
        int boardSize = getBoardSize(scanner);

        if (gameType == 'f' || gameType == 'F') {
            return new CheckerBoard(boardSize);
        }
        else {
            return new CheckerBoardMem(boardSize);
        }
    }

    private static int getLowercaseChar(Scanner scanner) {
        while (true) {
            String userInput = scanner.next();
            if (userInput.length() == 1 && Character.isLowerCase(userInput.charAt(0))) {
                return userInput.charAt(0);
            }
            System.out.println("Please enter a single lowercase letter:");
        }
    }

    private static char getGameType(Scanner scanner) {
        while (true) {
            String userInput = scanner.next().toUpperCase();
            if (userInput.equals("F") || userInput.equals("M")) {
                return userInput.charAt(0);
            }
            System.out.println("Enter 'F' for fast game of 'M' for memory-efficient game:");
        }
    }


    private static int getBoardSize(Scanner scanner) {
        while (true) {
            if (scanner.hasNextInt()) {
                int size = scanner.nextInt();
                // get rid of these magic numbers
                if (size == BOARD_SIZE_EIGHT || size == BOARD_SIZE_TEN || size == BOARD_SIZE_TWELVE || size == BOARD_SIZE_FOURTEEN || size == BOARD_SIZE_SIXTEEN) {
                    return size;
                }
            }
            scanner.nextLine();
            System.out.println("Please enter one of the following sizes:8, 10, 12, 14, 16:");
        }
    }
}
