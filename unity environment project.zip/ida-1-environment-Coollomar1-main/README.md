# IDA 1 – VR Environment ([Omar Masri])

## Environment Description
For IDA 1, I built a small house environment designed for VR on Meta Quest. The space includes three connected areas: a living room/lounge area, a kitchen area, and a bed near the lounge area. Each area is connected through open doorways/hallways so the user can freely walk through the full environment, and each room has a distinct visual identity using different materials and layout choices (ex: different wall/floor looks and furniture placement).

## Areas / Features
- Area 1: Living Room / Lounge
  - Seating (sofa) and a table to establish a “hangout” space.
- Area 2: Kitchen
  - Cabinets/counters and kitchen objects (ex: microwave) to communicate purpose.
- Area 3: Bed
  - Bed where user can sleep on. In the hallway leading to the chill room + the hallway to the door.

## Requirements Checklist
- XR Origin configured (head tracking works, spawn height feels correct)
- At least 3 distinct connected areas
- At least 2 transitions/doorways between areas
- Floors/walls/ceiling so the user feels “inside” an environment
- At least 5 environmental objects (furniture props)
- At least 5 materials applied across surfaces for visual variety
- Scale checked (doorways ~2m, furniture roughly real-world sized)
- Builds to Android/Quest and runs on-device without crashing

## Planning Ahead (IDA 2–4)
For IDA 2, I plan to add several grabbable objects placed on the kitchen counters and tables (ex: mugs, small items). For IDA 3, I’ll add a world-space UI panel near the living room area (ex: a wall-mounted panel or podium) to control settings/interactions. For IDA 4, I’ll improve polish with better lighting, audio per room (kitchen hum / room ambience), and small visual details.

## Known Issues
- There was some issues with building. It took me a while to fix these issues (had to configure multiple settings as well as move files around).
- My computer took 35 minutes to build, and then another 40 minutes to move the file contents so that I can post to GitHub classroom.
- The reason this submission is late (only on Github Classroom) is because my computer crashed trying to move the file contents, so I had to keep retrying multiple times.

## Time Spent
Approx. 12 hours total. This project took me a VERY long time to complete. I am still learning unity, and my computer takes long to respond.
